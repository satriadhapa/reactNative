import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(656, 552,355)',
    padding: 20,
  },
  paragraph: {
    marginTop: 24,
    borderWidth: 4,
    borderRadius: 6,
    backgroundColor: 'rgb(443, 200, 150)',
    fontSize: 40,
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export {styles};